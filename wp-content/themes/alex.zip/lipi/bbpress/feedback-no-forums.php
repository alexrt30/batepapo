<?php

/**
 * No Forums Feedback Part
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

<div class="bbp-template-notice">
	<p><?php _e( 'No forums were found here!', 'lipi' ); ?></p>
</div>
