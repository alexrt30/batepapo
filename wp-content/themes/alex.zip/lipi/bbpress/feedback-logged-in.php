<?php

/**
 * Logged In Feedback Part
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

<div class="bbp-template-notice info">
	<p><?php _e( 'You are already logged in.', 'lipi' ); ?></p>
</div>
